#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
set -o pipefail
export LC_ALL=C
[[ $EUID == 0 && $# == 3 ]] || { print -u2 'Run the installation command, not this helper.'; exit 1; }
share_root=${0:A:h:h}
share_disk=$1
share_desktop=$2
share_uid=$3
[[ $share_disk =~ '^disk[0-9]+s[0-9]+$' && $share_uid =~ '^[0-9]+$' ]] || exit 1
[[ -d $share_desktop && $(/usr/bin/stat -f %u "$share_desktop") == $share_uid ]] || exit 1
[[ $(/usr/bin/uname -m) == x86_64 ]] || { print -u2 'Only x86_64 supported.'; exit 1; }
share_kernel=$(/usr/bin/uname -r)
[[ ${share_kernel%%.*} == 24 ]] || { print -u2 'Requires macOS Sequoia 15.2 or newer 15.x.'; exit 1; }
share_minor=${${share_kernel#*.}%%.*}
(( share_minor >= 2 )) || exit 1
for share_marker in /System/Library/CoreServices/{oclp-mod,OpenCore-Legacy-Patcher}.plist; do
 [[ ! -e $share_marker ]] || { print -u2 'Root-patch marker found. Restore the native wireless environment first; this installer does not unpatch macOS.'; exit 1; }
done
/usr/sbin/ioreg -p IOService -r -c IOPCIDevice -a | /usr/bin/osascript -l JavaScript "$share_root/scripts/check-hardware.js"
/usr/bin/codesign --verify --strict "$share_root/Driver/AirportBZ-Sequoia.kext"
(cd "$share_root/Driver" && /usr/bin/shasum -a 256 -c SHA256SUMS.txt)
share_tmp=$(/usr/bin/mktemp -d /private/tmp/airportbz-install.XXXXXX)
share_esp=''
share_backup=''
share_touched=0
share_success=0
function hash_tree() {
 (cd "$1" && /usr/bin/find . -type f -print0 | /usr/bin/xargs -0 /usr/bin/shasum -a 256 | /usr/bin/sort)
}
function restore_config_metadata() {
 if [[ -f "$share_backup/EFI/OC/._config.plist" ]]; then
  /bin/cp -X "$share_backup/EFI/OC/._config.plist" "$share_esp/EFI/OC/._config.plist"
 fi
}
function finish() {
 share_rc=$?
 trap - EXIT
 if (( ! share_success && share_touched )); then
  print -u2 'Installation failed. Restoring the backed-up config and driver.'
  /bin/rm -rf "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext.staged" || share_rc=1
  /bin/rm -f "$share_esp/EFI/OC/config.plist.staged" || share_rc=1
  /bin/cp -X "$share_backup/EFI/OC/config.plist" "$share_esp/EFI/OC/config.plist" || share_rc=1
  restore_config_metadata || share_rc=1
  /bin/rm -rf "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext" || share_rc=1
  if [[ -d "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" ]]; then
   COPYFILE_DISABLE=1 /bin/cp -R -X "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" "$share_esp/EFI/OC/Kexts/" || share_rc=1
  fi
 fi
 if [[ -n $share_esp ]]; then
  /bin/sync
  /usr/sbin/diskutil unmount "$share_disk" >/dev/null || share_rc=1
  /usr/sbin/diskutil mount readOnly "$share_disk" >/dev/null || share_rc=1
 fi
 if [[ -n $share_backup && -d $share_backup ]]; then /usr/sbin/chown -R "$share_uid" "$share_backup"; fi
 /bin/rm -rf "$share_tmp"
 exit "$share_rc"
}
trap finish EXIT
/usr/sbin/diskutil info -plist "$share_disk" > "$share_tmp/disk.plist"
share_content=$(/usr/libexec/PlistBuddy -c 'Print :Content' "$share_tmp/disk.plist")
[[ $share_content == EFI ]] || { print -u2 'Selected partition is not an ESP.'; exit 1; }
share_uuid=$(/usr/libexec/PlistBuddy -c 'Print :DiskUUID' "$share_tmp/disk.plist")
share_mount=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist" 2>/dev/null || true)
if [[ -n $share_mount ]]; then /usr/sbin/diskutil unmount "$share_disk" >/dev/null; fi
/usr/sbin/diskutil mount readOnly "$share_disk" >/dev/null
/usr/sbin/diskutil info -plist "$share_disk" > "$share_tmp/disk.plist"
share_esp=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist")
share_cfg="$share_esp/EFI/OC/config.plist"
[[ -f $share_cfg ]] || { print -u2 'No EFI/OC/config.plist on selected ESP.'; exit 1; }
[[ -z $(/usr/bin/find "$share_esp/EFI" -type l -print -quit) ]] || { print -u2 'Unexpected EFI symlink. Inspect manually.'; exit 1; }
share_backup="$share_desktop/AirportBZ-EFI-backup-$(/bin/date +%Y%m%d-%H%M%S)-$share_disk"
/bin/mkdir -m 700 "$share_backup"
COPYFILE_DISABLE=1 /bin/cp -R -X "$share_esp/EFI" "$share_backup/EFI"
hash_tree "$share_esp/EFI" > "$share_backup/SHA256-before.txt"
hash_tree "$share_backup/EFI" > "$share_tmp/backup-check.txt"
/usr/bin/cmp -s "$share_backup/SHA256-before.txt" "$share_tmp/backup-check.txt" || { print -u2 'Full EFI backup verification failed.'; exit 1; }
print -r -- "$share_uuid" > "$share_backup/ESP-UUID.txt"
/usr/bin/osascript -l JavaScript "$share_root/scripts/patch-config.js" "$share_cfg" "$share_backup/config-after.plist" "$share_esp/EFI/OC/Kexts" > "$share_backup/config-changes.json"
/usr/bin/plutil -lint "$share_backup/config-after.plist"
/bin/cp -X "$share_root/scripts/rollback-root.sh" "$share_backup/rollback-root.sh"
/bin/cp -X "$share_root/scripts/restore.command" "$share_backup/恢复此次安装.command"
/bin/chmod 755 "$share_backup/rollback-root.sh" "$share_backup/恢复此次安装.command"
/usr/sbin/diskutil unmount "$share_disk" >/dev/null
/usr/sbin/diskutil mount "$share_disk" >/dev/null
/usr/sbin/diskutil info -plist "$share_disk" > "$share_tmp/disk.plist"
share_esp=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist")
[[ $(/usr/libexec/PlistBuddy -c 'Print :DiskUUID' "$share_tmp/disk.plist") == $share_uuid ]] || exit 1
hash_tree "$share_esp/EFI" > "$share_tmp/live-check.txt"
/usr/bin/cmp -s "$share_backup/SHA256-before.txt" "$share_tmp/live-check.txt" || { print -u2 'EFI changed during backup; refusing write.'; exit 1; }
share_dest="$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext"
[[ ! -e "$share_dest.staged" && ! -e "$share_esp/EFI/OC/config.plist.staged" ]] || exit 1
share_touched=1
COPYFILE_DISABLE=1 /bin/cp -R -X "$share_root/Driver/AirportBZ-Sequoia.kext" "$share_dest.staged"
/usr/bin/codesign --verify --strict "$share_dest.staged"
/bin/rm -rf "$share_dest"
/bin/mv "$share_dest.staged" "$share_dest"
/bin/cp -X "$share_backup/config-after.plist" "$share_esp/EFI/OC/config.plist.staged"
/usr/bin/plutil -lint "$share_esp/EFI/OC/config.plist.staged"
/bin/mv -f "$share_esp/EFI/OC/config.plist.staged" "$share_esp/EFI/OC/config.plist"
restore_config_metadata
/usr/bin/cmp -s "$share_backup/config-after.plist" "$share_esp/EFI/OC/config.plist"
(cd "$share_esp/EFI/OC/Kexts" && /usr/bin/shasum -a 256 -c "$share_root/Driver/SHA256SUMS.txt")
hash_tree "$share_dest" > "$share_backup/Kext-after-SHA256.txt"
hash_tree "$share_root/Driver/AirportBZ-Sequoia.kext" > "$share_tmp/driver-source.txt"
/usr/bin/cmp -s "$share_backup/Kext-after-SHA256.txt" "$share_tmp/driver-source.txt"
hash_tree "$share_esp/EFI" > "$share_backup/SHA256-after.txt"
function unrelated() {
 /usr/bin/awk '$0 !~ /  \.\/OC\/(config\.plist|\._config\.plist)$/ && $0 !~ /  \.\/OC\/Kexts\/AirportBZ-Sequoia\.kext\//' "$1"
}
unrelated "$share_backup/SHA256-before.txt" > "$share_tmp/unrelated-before.txt"
unrelated "$share_backup/SHA256-after.txt" > "$share_tmp/unrelated-after.txt"
/usr/bin/cmp -s "$share_tmp/unrelated-before.txt" "$share_tmp/unrelated-after.txt" || { print -u2 'Unrelated EFI files changed; refusing installation.'; exit 1; }
share_success=1
print -r -- "Installed. Verified full EFI backup: $share_backup"
print 'ESP will be remounted read-only. Reboot manually. No system files or power settings were changed.'
