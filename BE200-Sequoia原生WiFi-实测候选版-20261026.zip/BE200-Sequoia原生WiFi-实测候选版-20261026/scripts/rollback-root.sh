#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
set -o pipefail
[[ $EUID == 0 ]] || exit 1
share_backup=${0:A:h}
share_uuid=$(<"$share_backup/ESP-UUID.txt")
[[ $share_uuid =~ '^[0-9A-Fa-f-]{36}$' ]] || exit 1
[[ -f "$share_backup/config-after.plist" && -f "$share_backup/EFI/OC/config.plist" ]] || exit 1
share_tmp=$(/usr/bin/mktemp -d /private/tmp/airportbz-restore.XXXXXX)
share_mounted=0
function finish() {
 share_rc=$?
 trap - EXIT
 if (( share_mounted )); then
  /bin/sync
  /usr/sbin/diskutil unmount "$share_uuid" >/dev/null || share_rc=1
  /usr/sbin/diskutil mount readOnly "$share_uuid" >/dev/null || share_rc=1
 fi
 /bin/rm -rf "$share_tmp"
 exit "$share_rc"
}
trap finish EXIT
/usr/sbin/diskutil info -plist "$share_uuid" > "$share_tmp/disk.plist"
[[ $(/usr/libexec/PlistBuddy -c 'Print :Content' "$share_tmp/disk.plist") == EFI ]] || exit 1
share_mount=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist" 2>/dev/null || true)
if [[ -n $share_mount ]]; then /usr/sbin/diskutil unmount "$share_uuid" >/dev/null; fi
/usr/sbin/diskutil mount readOnly "$share_uuid" >/dev/null
share_mounted=1
/usr/sbin/diskutil info -plist "$share_uuid" > "$share_tmp/disk.plist"
share_esp=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist")
[[ $(/usr/libexec/PlistBuddy -c 'Print :DiskUUID' "$share_tmp/disk.plist") == $share_uuid ]] || exit 1
[[ -z $(/usr/bin/find "$share_esp/EFI" -type l -print -quit) ]] || { print -u2 'Unexpected EFI symlink. Inspect manually.'; exit 1; }
/usr/bin/cmp -s "$share_esp/EFI/OC/config.plist" "$share_backup/config-after.plist" || { print -u2 'Config changed since this install; refusing to overwrite later changes. Restore manually from the full backup.'; exit 1; }
(cd "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext" && /usr/bin/find . -type f -print0 | /usr/bin/xargs -0 /usr/bin/shasum -a 256 | /usr/bin/sort) > "$share_tmp/current-driver.txt"
/usr/bin/cmp -s "$share_tmp/current-driver.txt" "$share_backup/Kext-after-SHA256.txt" || { print -u2 'Driver changed after installation; inspect before rollback.'; exit 1; }
(cd "$share_backup/EFI" && /usr/bin/shasum -a 256 -c "$share_backup/SHA256-before.txt" >/dev/null)
/usr/sbin/diskutil unmount "$share_uuid" >/dev/null
/usr/sbin/diskutil mount "$share_uuid" >/dev/null
/usr/sbin/diskutil info -plist "$share_uuid" > "$share_tmp/disk.plist"
share_esp=$(/usr/libexec/PlistBuddy -c 'Print :MountPoint' "$share_tmp/disk.plist")
[[ $(/usr/libexec/PlistBuddy -c 'Print :DiskUUID' "$share_tmp/disk.plist") == $share_uuid ]] || exit 1
/bin/cp -X "$share_backup/EFI/OC/config.plist" "$share_esp/EFI/OC/config.plist"
if [[ -f "$share_backup/EFI/OC/._config.plist" ]]; then /bin/cp -X "$share_backup/EFI/OC/._config.plist" "$share_esp/EFI/OC/._config.plist"; fi
/bin/rm -rf "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext"
if [[ -d "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" ]]; then
 COPYFILE_DISABLE=1 /bin/cp -R -X "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" "$share_esp/EFI/OC/Kexts/"
fi
/usr/bin/cmp -s "$share_backup/EFI/OC/config.plist" "$share_esp/EFI/OC/config.plist"
if [[ -d "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" ]]; then
 (cd "$share_backup/EFI/OC/Kexts/AirportBZ-Sequoia.kext" && /usr/bin/find . -type f -print0 | /usr/bin/xargs -0 /usr/bin/shasum -a 256 | /usr/bin/sort) > "$share_tmp/expected-driver.txt"
 (cd "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext" && /usr/bin/find . -type f -print0 | /usr/bin/xargs -0 /usr/bin/shasum -a 256 | /usr/bin/sort) > "$share_tmp/restored-driver.txt"
 /usr/bin/cmp -s "$share_tmp/expected-driver.txt" "$share_tmp/restored-driver.txt"
else
 [[ ! -e "$share_esp/EFI/OC/Kexts/AirportBZ-Sequoia.kext" ]] || exit 1
fi
print 'Original config and previous AirportBZ bundle restored. Reboot manually.'
