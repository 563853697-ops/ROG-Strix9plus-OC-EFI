ObjC.import('Foundation');
function run(argv) {
    var bytes = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
    var error = $();
    var root = $.NSPropertyListSerialization.propertyListWithDataOptionsFormatError(bytes, 0, null, error);
    if (!root || root.isNil()) throw new Error('Cannot parse PCI registry');
    var matches = [];
    function hexData(node, key) {
        var item = node.objectForKey(key);
        if (!item || item.isNil()) return '';
        return ObjC.unwrap(item.base64EncodedStringWithOptions(0));
    }
    function walk(node) {
        if (node.isKindOfClass($.NSArray)) {
            for (var i = 0; i < node.count; i++) walk(node.objectAtIndex(i));
        } else if (node.isKindOfClass($.NSDictionary)) {
            var vendor = hexData(node, 'vendor-id');
            var device = hexData(node, 'device-id');
            if (vendor === 'hoAAAA==' && (device === 'KycAAA==' || device === 'QHcAAA==')) {
                matches.push(device === 'KycAAA==' ? 'BE200:8086:272B' : 'BE201:8086:7740');
            }
            var children = node.objectForKey('IORegistryEntryChildren');
            if (children && !children.isNil()) walk(children);
        }
    }
    walk(root);
    if (!matches.length) throw new Error('No supported BE200/BE201 PCI ID found');
    return matches.join('\n');
}
